from django.apps import AppConfig


class UtilisateursConfig(AppConfig):
    name = 'utilisateurs'
